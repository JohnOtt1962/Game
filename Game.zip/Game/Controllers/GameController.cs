﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GameManagement;
using Game.Models;
using Newtonsoft.Json;

namespace Game.Controllers
{
    public class GameController : Controller
    {
        private readonly GameManager _gameManager;

        public GameController()
        {
            _gameManager = new GameManager();
        }

        // GET: Game
        public ActionResult Index()
        {
            string serializedGame = _gameManager.GetTiles(5);
            return View(JsonConvert.DeserializeObject<Models.GameModel>(serializedGame));
        }

        [HttpPost, ActionName("DetermineFate")]
        public ActionResult DetermineFate()
        {
            string serializedGame = _gameManager.FindCellFate();
            return View("Index", JsonConvert.DeserializeObject<Models.GameModel>(serializedGame));
        }

        [HttpPost]
        public ActionResult ChangeSize()
        {
            int sideCount = Convert.ToInt32(Request.Form["drpSideCount"].ToString());
            string serializedGame = _gameManager.GetTiles(sideCount);
            return View("Index", JsonConvert.DeserializeObject<Models.GameModel>(serializedGame));
        }
    }
}