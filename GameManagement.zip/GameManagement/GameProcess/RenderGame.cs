﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameManagement.Models;

namespace GameManagement.GameProcess
{
    public class RenderGame
    {
        public string BuildGame(GameModel game)
        {
            int sideCount = Convert.ToInt32(Math.Sqrt(game.GameSpace.Count));
            return GetRowTemplate(sideCount, game);
        }

        private string GetRowTemplate(int sideCount, GameModel game)
        {
            string htmlConcat = "";
            string rowTemplate = "<tr>#ROWCONTENTS#</tr>";

            for (var i = 0; i < sideCount; i++)
            {
                string cellContent = GetCellTemplate(sideCount, i, game);
                htmlConcat += rowTemplate.Replace("#ROWCONTENTS#", cellContent);
            }

            return htmlConcat;
        }

        private string GetCellTemplate(int sideCount, int row, GameModel game)
        {
            string cellConcat = "";

            for (var i = 0; i < sideCount; i++)
            {
                string color = game.GameSpace[sideCount * row + i].Color;
                var cellTemplate = "<td id='#IDX#' style='height: 100px; width: 100px; background: #COLOR#'>&nbsp;</td>";
                cellTemplate = cellTemplate.Replace("#IDX#", Convert.ToString(row) + "_" + Convert.ToString(i + 1));
                cellTemplate = cellTemplate.Replace("#COLOR#", color);
                cellConcat += cellTemplate;
            }

            return cellConcat;
        }
    }
}