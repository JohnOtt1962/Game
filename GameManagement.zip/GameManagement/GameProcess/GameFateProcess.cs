﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameManagement.Models;
using Newtonsoft.Json;
using System.Web;

namespace GameManagement.GameProcess
{
    public class GameFateProcess
    {
        public GameModel FindCellFate()
        {
            GameModel gm = (GameModel)HttpContext.Current.Cache["Tiles"];
            int tileCount = gm.GameSpace.Count;
            int sideCount = Convert.ToInt32(Math.Sqrt(tileCount));

            for(int i = 0; i < tileCount; i++)
            {
                int liveNeighbors = FindAdjacentLiveCellCount(sideCount, i, gm);
                if (gm.GameSpace[i].Color == "red" && liveNeighbors < 2)
                    gm.GameSpace[i].Color = "black";
                else if (gm.GameSpace[i].Color == "red" && liveNeighbors >= 2 && liveNeighbors <= 3)
                    gm.GameSpace[i].Color = "red";
                else if (gm.GameSpace[i].Color == "red" && liveNeighbors > 3)
                    gm.GameSpace[i].Color = "black";
                else if (gm.GameSpace[i].Color == "black" && liveNeighbors == 3)
                    gm.GameSpace[i].Color = "red";
            }

            return gm;
        }

        private int FindAdjacentLiveCellCount(int sideCount, int idx, GameModel gm)
        {
            int liveCount = 0;

            for (int i = -1; i < 2; i++)
            {

                var downIdx = idx + sideCount + i;
                var upIdx = idx - sideCount + i;

                if (downIdx >= 0 && downIdx < gm.GameSpace.Count && gm.GameSpace[downIdx].Color == "red")
                    liveCount++;

                if (upIdx >= 0 && downIdx < gm.GameSpace.Count && gm.GameSpace[upIdx].Color == "red")
                    liveCount++;

            }

            if (idx - 1 >= 0 && gm.GameSpace[idx - 1].Color == "red")
                liveCount++;

            if (idx + 1 < gm.GameSpace.Count && gm.GameSpace[idx + 1].Color == "red")
                liveCount++;

            return liveCount;
        }
    }
}
