﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameManagement.Models;
using Newtonsoft.Json;
using System.Web;

namespace GameManagement.GameProcess
{
    public class ProcessGame
    {
        public GameModel FillTiles(int sideCount)
        {
            Random rnd = new Random();

            GameModel gm = new GameModel
            {
                GameSpace = new List<GameItemModel>()
            };

            for(int i = 0; i < sideCount; i++)
            {
                for(int j = 0; j < sideCount; j++)
                {
                    string color = "red";
                    int outcome = rnd.Next();

                    if (outcome % 2 == 0)
                        color = "black";

                    GameItemModel gim = new GameItemModel
                    {
                        Row = i,
                        Col = j,
                        Survived = false,
                        Color = color
                    };

                    gm.GameSpace.Add(gim);
                }
            }

            HttpContext.Current.Cache["Tiles"] = gm;
            return gm;
        }
    }
}