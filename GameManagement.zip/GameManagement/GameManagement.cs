﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameManagement.GameProcess;
using GameManagement.Models;
using Newtonsoft.Json;

namespace GameManagement
{
    public class GameManager
    {
        private readonly ProcessGame _processGame;
        private readonly GameFateProcess _fateProcessor;
        private readonly RenderGame _renderGame;

        public GameManager()
        {
            _processGame = new ProcessGame();
            _fateProcessor = new GameFateProcess();
            _renderGame = new RenderGame();
        }

        public string GetTiles(int sideCount)
        {
            GameModel gm = _processGame.FillTiles(sideCount);
            gm.GameHtml = _renderGame.BuildGame(gm);
            return JsonConvert.SerializeObject(gm);
        }

        public string FindCellFate()
        {
            GameModel gm = _fateProcessor.FindCellFate();
            gm.GameHtml = _renderGame.BuildGame(gm);
            return JsonConvert.SerializeObject(gm);
        }
    }
}