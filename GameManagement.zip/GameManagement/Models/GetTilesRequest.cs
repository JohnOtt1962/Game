﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameManagement.Models
{
    public class GetTilesRequest
    {
        public int SideCount { get; set; }
    }
}