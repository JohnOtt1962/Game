﻿using System;
using System.Collections.Generic;

namespace GameManagement.Models
{
    public class GameModel
    {
        public List<GameItemModel> GameSpace { get; set; }
        public string GameHtml { get; set; }
    }

    public class GameItemModel
    {
        public int Row { get; set; }
        public int Col { get; set; }
        public string Color { get; set; }
        public bool Survived { get; set; }
    }
}